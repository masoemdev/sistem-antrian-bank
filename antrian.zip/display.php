<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ambil Antrian</title>
    <style>
      body {
        background-color: black;
        color: white;
        text-align: center;
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 15px;
        padding: 2rem;
      }
      h1 {
        letter-spacing: 10px;
        font-size: 2rem;
      }

      .display-label {
        font-size: 6rem;
        color: yellow;
        letter-spacing: 5px;
      }
      .display {
        font-size: 32vw;
        font-weight: bold;
        color: #00ff88;
      }
      .btn-antrian {
        font-size: 5rem;
        padding: 1rem 2rem;
        border-radius: 0.5rem;
        background: #0d6efd;
        color: white;
      }
      .btn-img {
        height: 7rem;
      }
      .logo {
        position: absolute;
        z-index: 100;
        top: 50px;
        width: 200px;
      }
    </style>
  </head>
  <body
    class="container vh-100 d-flex flex-column justify-content-center align-items-center p-4"
  >
    <!-- <img src="img/logo.png" alt="logo" class="logo" /> -->
    <h1 class="mb-4">NOMOR ANTRIAN</h1>
    <div class="display-label">SEDANG DIPANGGIL</div>
    <div class="display">0031</div>
  </body>
</html>
