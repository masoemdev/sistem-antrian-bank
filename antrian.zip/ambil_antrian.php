<?php
$s = "SELECT 1 FROM tb_antrian WHERE waktu >= '$today' AND waktu <= '$now' ";
$q = mysqli_query($cn, $s) or die(mysqli_error($cn));

$nomor_baru = mysqli_num_rows($q) + 1;
$s = "INSERT INTO tb_antrian (nomor) VALUES ('$nomor_baru')";
$q = mysqli_query($cn, $s) or die(mysqli_error($cn));
?>
<style>
  .blok-sedang-print {
    font-size: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    /* gap: 50px; */
    height: 100vh;
  }

  .blok-mohon {
    transform: translateY(-5vh);
  }

  .sedang-mencetak {
    margin: 30px 0 50px 0;
  }

  .kembali {
    display: none;
    position: absolute;
    bottom: 50px;
    left: 0;
    right: 0;

  }
</style>
<div class="blok-sedang-print">
  <div class="blok-mohon">
    <div class="perintah">Mohon Tunggu !</div>
    <div class="sedang-mencetak">
      Sedang mencetak Antrian Anda...
    </div>
    <div>
      <img src="img/loading.gif" alt="loading">
    </div>
  </div>
  <div class="kembali">
    <a href="?">Kembali</a>
  </div>
</div>
<script>
  setTimeout(() => $('.kembali').fadeIn(3000), 8000);
  setTimeout(() => location.replace('?'), 16000);
</script>