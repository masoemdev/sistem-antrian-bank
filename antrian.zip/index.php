<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Antrian App</title>
  <link rel="stylesheet" href="antrian.css">
  <script src="js/jquery-3.7.1.min.js"></script>
</head>

<body>
  <?php
  include 'cn.php';
  $today = date('Y-m-d');
  $now = date('Y-m-d H:i:s');

  $p = $_GET['p'] ?? 'nasabah';
  include "$p.php";
  ?>
</body>

</html>