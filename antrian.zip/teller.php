<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ambil Antrian</title>
    <style>
      body {
        background-color: #f8f9fa;
        text-align: center;
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        display: flex;
        flex-direction: column;
        justify-content: center;
        /* gap: 10px; */
        /* padding: 1rem; */
        height: 100vh;
        overflow: hidden;
      }
      h1 {
        font-size: 4vh;
      }

      .nomor-antrian-label {
        font-size: 8vh;
        color: #dc3545;
      }
      .nomor-antrian {
        font-size: 30vh;
      }
      .btn-antrian {
        font-size: 10vh;
        padding: 1rem 2rem;
        border-radius: 0.5rem;
        background: #dc3545;
        color: white;
      }
      .btn-img {
        height: 15vh;
      }
      .logo {
        position: absolute;
        z-index: 100;
        top: 20px;
        width: 100px;
      }
      .blok-logo {
        text-align: left;
        padding-left: 20px;
      }

      @media (max-width: 500px) {
        .logo {
          position: static;
          top: 0;
          width: 50vw;
        }
        .blok-logo {
          text-align: center;
        }
        h1 {
          font-size: 2rem;
        }
        .nomor-antrian-label {
          font-size: 3rem;
        }
        .nomor-antrian {
          font-size: 8rem;
        }
        .btn-antrian {
          font-size: 4rem;
          text-align: center;
        }
        .btn-img {
          display: inline-block;
        }
      }
    </style>
  </head>
  <body
    class="container vh-100 d-flex flex-column justify-content-center align-items-center p-4"
  >
    <div class="blok-logo">
      <img src="img/logo.png" alt="logo" class="logo" />
    </div>
    <h1 class="mb-4">TELLER: SOLIHIN</h1>
    <div class="nomor-antrian-label">Antrian Saat Ini</div>
    <div class="nomor-antrian">0034</div>
    <button id="ambilBtn" class="btn btn-danger btn-antrian">
      Next Antrian
      <img src="img/hand-white.png" alt="hand-icon" class="btn-img" />
    </button>
    <div id="loading" class="mt-4 text-secondary" style="display: none">
      <div class="spinner-border text-danger" role="status"></div>
      <p class="mt-2">Memproses...</p>
    </div>
    <div
      id="hasil"
      class="antrian-box text-success mt-3"
      style="display: none"
    ></div>

    <script src="../assets/vendor/jquery/jquery-3.7.1.min.js"></script>
    <script>
      $("#ambilBtn").click(function () {
        $("#ambilBtn").prop("disabled", true);
        $("#loading").show();
        $("#hasil").hide();

        $.post(
          "api/ambil_antrian.php",
          function (response) {
            $("#loading").hide();
            $("#hasil")
              .text("A" + String(response.nomor).padStart(3, "0"))
              .show();
            $("#ambilBtn").prop("disabled", false);
          },
          "json"
        ).fail(function () {
          $("#loading").hide();
          alert("Gagal mengambil antrian. Coba lagi.");
          $("#ambilBtn").prop("disabled", false);
        });
      });
    </script>
  </body>
</html>
