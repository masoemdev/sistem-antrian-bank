<style>
  body {
    background: black;
  }

  .kertas-thermal {
    text-align: center;
    font-family: consolas, "Courier New", Courier, monospace;
    font-size: 12px;
    background: white;
    color: black;
    width: 57.5mm;
    height: 65mm;
  }

  .nomor-antrian-print-label {
    margin-top: 10px;
    font-size: 20px;
  }

  .nomor-antrian-print {
    font-size: 60px;
  }

  .antrian-saat-ini {
    font-size: 20px;
  }

  .estimasi {
    font-size: 15px;
  }

  .slogan {
    margin-top: 10px;
    font-size: 15px;
  }
</style>
<div class="kertas-thermal">
  <h1 class="nomor-antrian-print-label">Antrian Anda</h1>
  <div class="nomor-antrian-print">0034</div>
  <div class="antrian-saat-ini">antrian saat ini: 0025</div>
  <div class="estimasi">estimasi 12 menit menunggu</div>
  <div class="slogan">
    BPRS Al-Ma'soem <br />Meraih Sukses Bersama <br />Kemaslahatan Ummat
  </div>
</div>
<script>
  // window.onload = () => {
  //   // Tunggu sebentar untuk pastikan halaman benar-benar siap
  //   setTimeout(() => {
  //     window.print();
  //   }, 500); // 0.5 detik delay supaya teks termuat dulu
  // };
</script>

<script src="../assets/vendor/jquery/jquery-3.7.1.min.js"></script>
<script>
  function loadAntrian() {
    console.log("load");

    $.ajax({
      url: "ajax/ajax_ambil_antrian.php",
      success: function(a) {
        console.log(a);
        $("#nomor-antrian-print").text(a);
      },
    });
  }

  $(function() {
    $("#zzz").click(function() {
      alert("zzz");
      $.ajax({
        url: "api/ambil_antrian.php",
        success: function(a) {
          alert(a);
          console.log(a);
          $("#nomor-antrian-print").text(a);
        },
        error: function(xhr, status, error) {
          alert("Terjadi kesalahan saat mengambil data antrian: " + error);
          console.error("Status:", status);
          console.error("Error detail:", xhr.responseText);
          $("#nomor-antrian-print").text("Gagal mengambil nomor antrian");
        },
      });
    });
    // setInterval(loadAntrian, 2000);
    // loadAntrian(); // awal load
  });
</script>