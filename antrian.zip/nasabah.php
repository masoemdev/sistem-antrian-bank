<?php
$antrian = 32;

$s = "SELECT nomor FROM tb_antrian ORDER BY waktu DESC LIMIT 1 ";
$q = mysqli_query($cn, $s) or die(mysqli_error($cn));
$d = mysqli_fetch_assoc($q);
$antrian = $d['nomor'];


$antrian_show = sprintf('%04d', $antrian);
?>
<img src="img/logo.png" alt="logo" class="logo" />
<h1 class="selamat-datang">Selamat Datang Nasabah!</h1>
<div class="nomor-antrian-label">Silahkan Ambil Antrian Anda !</div>
<div class="nomor-antrian">
  <div>
    <?= $antrian_show ?>
  </div>
</div>
<a href="?p=ambil_antrian" class="btn-antrian">
  Ambil Antrian
  <img src="img/hand-white.png" alt="hand-icon" class="btn-img" />
</a>